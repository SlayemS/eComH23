<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Index 2</title>
</head>
<body>
	<h1>Welcome!</h1>
	<p>Welcome to this application's second index</p>
	<a href="/index.php?url=/Main/index">Index</a>
	<a href="/index.php?url=/Main/index2">Index 2</a>
	<a href="/index.php?url=/Main/greetings">Greetings</a>
</body>
</html>