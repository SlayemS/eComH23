<?php
include 'app/core/autoload.php';