<?php
namespace app\core;

class Controller
{

	function view($name, $data = [])	// default empty array
	{
		include('app/views/' . $name . '.php');
	}
	
}